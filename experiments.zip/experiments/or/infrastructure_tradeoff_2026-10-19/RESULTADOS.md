# Experimento siguiente: cobertura turística frente a infraestructura de alojamiento

**Fecha:** 19 de octubre de 2026. **Estado:** cálculo exacto completado; comparación de decisiones, no campaña publicitaria observada.

## Pregunta

Con un presupuesto **hipotético** de MX$30,000 para seis colocaciones a MX$5,000 cada una, ¿qué cambia si, además de cubrir tipos distintos de actividades documentadas, intentamos favorecer municipios con infraestructura de alojamiento?

Esta segunda magnitud proviene del conteo de **establecimientos de alojamiento** de DENUE en el inventario municipal. **No equivale a visitas, ocupación, popularidad, capacidad hotelera en cuartos ni resultados comerciales.**

## Datos y método

Se conserva el universo comparable del optimizador anterior: **61 municipios** con las 216 relaciones municipio–actividad aceptadas y **78 tipos específicos** diferenciados. Los 14 municipios incorporados recientemente sí aparecen en el análisis de cobertura documental (75 en total), pero todavía no tienen una correspondencia validada y homogénea con los 78 tipos; por ello no se les asigna artificialmente un valor de cobertura dentro de esta optimización.

Variables binarias: seleccionar seis municipios y marcar como cubierto cada tipo de actividad que figure en al menos un municipio seleccionado. Se usa programación entera mixta (MILP). Primero se conserva la selección original que maximiza cobertura (47 tipos); después se maximiza el **total de establecimientos de alojamiento** sujeto a cubrir como mínimo 47, 43, 38, 33 o 0 tipos. Los umbrales 43, 38 y 33 corresponden al redondeo hacia arriba de 90%, 80% y 70% de 47, respectivamente. No representan umbrales oficiales de política pública.

## Resultados calculados

| Escenario (seis municipios) | Tipos documentados cubiertos | Establecimientos de alojamiento en total |
|---|---:|---:|
| Selección original, máxima variedad | 47 | 139 |
| Máximo alojamiento sin perder ninguna actividad cubierta | 47 | 139 |
| Alojamiento máximo con al menos 90% de la cobertura | 43 | 386 |
| Alojamiento máximo con al menos 80% de la cobertura | 38 | 669 |
| Alojamiento máximo con al menos 70% de la cobertura | 33 | 720 |
| Alojamiento máximo sin mínimo de cobertura | 15 | 815 |

**Hallazgo:** exigir las 47 actividades conserva la selección original y los 139 establecimientos. Permitir perder cuatro tipos documentados (de 47 a 43) hace posible una cartera con 386 establecimientos. El modelo de alojamiento sin restricción de variedad llega a 815 establecimientos, pero cubre solo 15 tipos. No tenemos evidencia de que 815 negocios produzcan más viajeros que 139 ni de que promocionarlos genere mayor retorno.

## Ejemplo de cambio de selección

El escenario con al menos 90% de la cobertura sustituye **Atlahuilco** por **Tecolutla**; conserva Catemaco, Coatepec, Fortín, Papantla y San Andrés Tuxtla. Esa sustitución reduce la variedad de 47 a 43, mientras el conteo conjunto de establecimientos pasa de 139 a 386. **El resultado refleja el indicador elegido, no una evaluación de atractivo turístico o equidad territorial.**

## Implicación para las UCA

- **Investigación de Operaciones:** cartera de máxima cobertura y frontera entre dos criterios mediante una restricción mínima de cobertura; selección exacta, no una suma arbitraria de «puntos de popularidad».
- **Minería de Datos:** taxonomía de 78 tipos específicos, provenientes de relaciones con fuentes; los nuevos 14 municipios quedan en una capa de evidencia separada por comparabilidad.
- **Mercadotecnia Digital:** dos narrativas de campaña posibles, una de experiencias diversas y otra más vinculada a infraestructura receptiva, **sin afirmar que alguna vende mejor**.
- **Modelos Estocásticos:** incertidumbre de evidencia y demanda permanece pendiente; los resultados de la simulación Monte Carlo del proyecto se preservan por separado. Este experimento MILP no se denomina estocástico.

## Reproducción

Desde la raíz del repositorio:

```bash
python experiments/or/infrastructure_tradeoff_2026-10-19/run.py
```

Requiere `numpy` y `scipy` con `scipy.optimize.milp`. Relee el SQLite congelado que está en `experiments/marketing/2026-10-19/sources/`; produce `comparison.csv`, `selections.csv` y `metadata.json` sin modificar la base. **No es necesario ejecutarlo para usar los resultados: los CSV ya están incluidos.**
