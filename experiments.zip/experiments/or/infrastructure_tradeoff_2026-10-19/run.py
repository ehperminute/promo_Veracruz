#!/usr/bin/env python3
"""Evidence-constrained promotion portfolio: exact MILP, no invented demand."""
from __future__ import annotations
import csv, json, sqlite3
from pathlib import Path
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]  # experiments
DB=ROOT/'marketing'/'2026-10-19'/'sources'/'veracruz_pp3_master_RECOVERED.sqlite'
SIX=ROOT/'marketing'/'2026-10-19'/'sources'/'selected_municipalities.csv'
assert DB.exists(), DB
conn=sqlite3.connect(DB)
pairs=conn.execute('select municipality_id,feature_id from s4_statewide_evidence_pairs_v1').fetchall()
items=conn.execute('''select c.municipality_id,m.name_official,coalesce(c.alojamiento_n,0)
from s4_statewide_municipal_coverage_v1 c join municipalities m on m.municipality_id=c.municipality_id''').fetchall()
byid={str(i).lstrip('0'):(name,int(lodging)) for i,name,lodging in items}
by_m={}
for mid, fid in pairs: by_m.setdefault(str(mid).lstrip('0'),set()).add(str(fid))
municipalities=sorted(by_m)
features=sorted({f for a in by_m.values() for f in a})
n=len(municipalities);k=len(features)
feat_idx={f:j for j,f in enumerate(features)}
entries=[(j,feat_idx[f]) for j,m in enumerate(municipalities) for f in by_m[m]]
cap=np.array([byid[m][1] for m in municipalities],dtype=float)
# Indicators x_j: municipality selected; y_i: activity feature covered.
# y_f >= x_m for every municipality with feature f and y_f <= sum(x_m with feature f).
num_rows=1+k+len(entries)+1
mat=lil_matrix((num_rows,n+k),dtype=float)
lo=np.full(num_rows,-np.inf);hi=np.full(num_rows,np.inf)
mat[0,:n]=1;lo[0]=hi[0]=6
r=1
for f in features:
 j=feat_idx[f]
 mat[r,n+j]=1
 for i,m in enumerate(municipalities):
  if f in by_m[m]: mat[r,i]=-1
 hi[r]=0;r+=1
for i,j in entries:
 mat[r,i]=1;mat[r,n+j]=-1;hi[r]=0;r+=1
coverage_row=r
mat[r,n:]=1
constraints=mat.tocsr()

def solve(floor=None,coverage_only=False):
 l=lo.copy();h=hi.copy()
 if floor is not None:l[coverage_row]=floor
 c=np.zeros(n+k)
 if coverage_only:
  c[n:]=-1
  # secondary accommodation tie-break cannot compromise one activity feature
  c[:n]=-cap/(1+cap.sum())*.01
 else:
  c[:n]=-cap
  # avoid arbitrarily changing capacity maximum; tie favor more feature coverage
  c[n:]=-0.00001
 res=milp(c,integrality=np.ones(n+k),bounds=Bounds(np.zeros(n+k),np.ones(n+k)),constraints=LinearConstraint(constraints,l,h),options={'time_limit':90, 'mip_rel_gap':0.0})
 if res.x is None or res.status not in (0,1):raise RuntimeError(f'No solution: status={res.status} message={res.message}')
 idx=[j for j in range(n) if res.x[j]>.5]; cov=set().union(*(by_m[municipalities[j]] for j in idx))
 return {'selected':[{'municipality_id':municipalities[j],'municipality':byid[municipalities[j]][0], 'lodging_establishments':int(cap[j]),'documented_activity_types':len(by_m[municipalities[j]])} for j in idx], 'coverage':len(cov),'lodging_sum':int(cap[idx].sum()),'solver':str(res.message)}

base_ids=[]
with open(SIX,encoding='utf-8-sig',newline='') as f:
 for row in csv.DictReader(f):
  if str(row['budget_mxn'])=='30000' and row['priority']=='all':base_ids.append(str(row['municipality_id']).lstrip('0'))
assert len(base_ids)==6,base_ids
base_cov=set().union(*(by_m[m] for m in base_ids))
base={'selected':[{'municipality_id':m,'municipality':byid[m][0],'lodging_establishments':byid[m][1],'documented_activity_types':len(by_m[m])} for m in base_ids], 'coverage':len(base_cov),'lodging_sum':sum(byid[m][1] for m in base_ids)}
maximum=solve(coverage_only=True)
assert base['coverage']==maximum['coverage'],(base['coverage'],maximum['coverage'])
levels=[('Existing coverage-first published selection',None,base),('Highest accommodations with same full coverage',maximum['coverage'],None),('Highest accommodations with at least 90% coverage',int(np.ceil(.9*maximum['coverage'])),None),('Highest accommodations with at least 80% coverage',int(np.ceil(.8*maximum['coverage'])),None),('Highest accommodations with at least 70% coverage',int(np.ceil(.7*maximum['coverage'])),None),('Highest accommodations (no coverage minimum)',0,None)]
results=[]; sel=[]
for title,floor,baseline in levels:
 d=baseline if baseline else solve(floor=floor)
 results.append({'scenario':title,'number_municipalities':6,'distinct_documented_activity_types':d['coverage'],'accommodation_establishments_sum':d['lodging_sum'],'coverage_minimum':floor if floor is not None else '', 'no_measured_popularity_or_roi':True})
 for place in d['selected']:sel.append({'scenario':title,**place})
assert all(x['distinct_documented_activity_types']<=maximum['coverage'] for x in results)
for name,rows in [('comparison.csv',results),('selections.csv',sel)]:
 with open(HERE/name,'w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(HERE/'metadata.json').write_text(json.dumps({'source':'SQLite s4_statewide_evidence_pairs_v1 and s4_statewide_municipal_coverage_v1','eligible_municipalities':n,'distinct_feature_types':k,'budget_mxn':30000,'placements':6,'unit_cost_mxn_is_hypothetical':5000,'accommodation': 'DENUE establishment proxy, NOT actual tourists or popularity','new_14_municipalities':'Not folded into the 216 specific feature relationships; covered in complementary evidence audit.'},ensure_ascii=False,indent=2),encoding='utf-8')
for x in results:print(f"{x['scenario']}: {x['distinct_documented_activity_types']} activities; {x['accommodation_establishments_sum']} accommodation establishments")
