# Veracruz — actualización de cobertura y propuesta de campaña (19 oct 2026)

Este paquete **integra** los 40 registros verificados en el **análisis de cobertura documental** y el **plan de contenido**. No reescribe las 216 relaciones originales de actividad específica ni finge que 26 sitios nuevos estén abiertos al turismo o tengan entrada de visitante confirmada.

## Hallazgo actualizado

- 212 municipios en el inventario.
- 61 municipios con 216 relaciones aceptadas municipio–actividad (conjunto congelado para reproducibilidad).
- 14 municipios adicionales con 40 decisiones de revisión, de las cuales 39 se conservan como información turística investigada. No se superponen con los 61 anteriores.
- Resultado: **75 municipios con algún tipo de evidencia turística documentada**, según criterios combinados y explícitamente distintos; 137 sin esa cobertura en esta revisión.
- Desglose de los 40: 26 sitios físicos, 7 festivales/eventos, 5 experiencias regionales, 1 patrimonio arqueológico sin acceso demostrado y 1 entrada genérica rechazada.

**Nota metodológica:** 75 no equivale a 75 municipios con actividades reservables y la prueba de asociaciones de 36 pares de categorías **no se ha recalculado como si los 40 fueran relaciones equivalentes**. Las categorías del nuevo catálogo son heterogéneas. Cualquier prueba posterior requerirá una taxonomía y un universo de muestreo comparables.

## Propuesta de mercadotecnia

Se toma una decisión de OR **ya ejecutada**: seis destinos, presupuesto hipotético de 30,000 MXN, costo asumido de 5,000 MXN por colocación. La estrategia «cobertura primero» selecciona Atlahuilco, Catemaco, Coatepec, Fortín, Papantla y San Andrés Tuxtla. Cobertura: 47 actividades distintas, de las cuales 14 cuentan con pasajes originales preservados. La alternativa «texto original primero» cubre 39 actividades y 19 respaldadas por pasajes originales. Los resultados **no son popularidad** ni retorno publicitario.

Contiene 6 textos promocionales con fuente original, hipótesis de interés de audiencia, llamadas a la acción y planes de medición. También dos nuevas opciones editoriales documentadas (Acayucan y Perote), que **no** forman parte de los seis placements calculados; antes de publicidad hay que comprobar condiciones vigentes.

## Archivos

- `results/coverage_212_before_after.csv`: comparación de cobertura en 212 municipios; nuevo material distinguido del inventario antiguo.
- `results/verified_14_sources_reviewed.csv`: 40 decisiones auditables con URL y limitaciones.
- `results/marketing_portfolio_30000.csv`: seis fichas publicitarias, fuentes y medición propuesta.
- `results/portfolio_comparison_30000.csv`: resultados exactos de las dos estrategias originales.
- `results/new_evidence_content_pilots.csv`: dos historias editoriales adicionales, no pautas activas.
- `results/measurement_plan.csv`: eventos y métricas que **habría que instrumentar**; todavía no hay resultados.
- `results/proposed_campaign_municipalities.geojson`: puntos de referencia municipales, **no** entradas de atracción.
- `results/proposed_campaign_for_site.json`: contenido para una integración futura al mapa sin rehacer el análisis.
- `results/audit_summary.json`: cifras, fuente y hash de la base SQLite utilizada.
- `Informe_Mineria_y_Mercadotecnia_Veracruz.docx`: informe legible para las UCAs.
- `sources/`: copia de entradas originales necesarias para una reproducción autónoma.
- `build.py`: programa Python reproducible sin instalaciones adicionales; `python build.py` regenera los archivos en `results/`.

## Limitaciones importantes

Los presupuestos unitarios son supuestos didácticos, no cotizaciones. No existen CTR, visitas incrementales, conversiones, campañas reales o tasas de reserva medidas. Las afinidades de audiencia son hipótesis editoriales basadas en actividades documentadas, no segmentos conductuales descubiertos. La ausencia de evidencia no equivale a demanda nula. Los puntos GeoJSON son coordenadas municipales aproximadas sin validez para rutas precisas.

**No necesitas iniciar Codespaces para leer o evaluar los resultados.** Tampoco es necesario que instales un parche de la web; este entregable cierra un análisis académico y prepara datos para integración posterior al mapa.
