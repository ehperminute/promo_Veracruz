"""Produce a reproducible evidence-coverage update and proposed marketing campaign.
Reads recovered PP3 SQLite and two prior verified CSV archives; never changes the source database.
No campaign response, consumer demand, costs, or booking availability are invented.
"""
from pathlib import Path
import csv, json, sqlite3, io, zipfile, hashlib, collections
from itertools import combinations

ROOT=Path(__file__).resolve().parent
ASSET=ROOT/'sources'
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
DB=ASSET/'veracruz_pp3_master_RECOVERED.sqlite'
REVIEW=ASSET/'verification_40.csv'
OR=ASSET/'selected_municipalities.csv'
SCENARIO=ASSET/'scenario_cross_evaluation.csv'

def loadcsv(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def write(name, rows):
 if not rows:return
 with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),extrasaction='ignore');w.writeheader();w.writerows(rows)

con=sqlite3.connect(f'file:{DB}?mode=ro',uri=True)
accepted=con.execute('select municipality_id,feature_id,family,original_text_support_count,source_urls from s4_statewide_evidence_pairs_v1 order by 1,2').fetchall()
names={r[0]:r[1] for r in con.execute('select municipality_id,name_official from municipalities')}
con.close()
review=loadcsv(REVIEW)
assert len(accepted)==216,(len(accepted),'expected unchanged analysis baseline')
assert len(review)==40
assert len({r['municipality_id'] for r in review})==14
base_ids=set(r[0] for r in accepted)
new_ids=set(r['municipality_id'] for r in review)
assert not base_ids&new_ids,'14 additional municipalities assumed to have zero strict baseline activities; investigate!'
statuses=collections.Counter(r['verification_decision'] for r in review)
assert statuses['CONFIRMADO_SITIO_O_AREA']==26 and statuses['DESCARTADO_COMO_ATRACCION_INDIVIDUAL']==1
base_by_id=collections.defaultdict(list)
for m,feature,family,support,urls in accepted:base_by_id[m].append((feature,family,support,urls))
review_by_id=collections.defaultdict(list)
for r in review:review_by_id[r['municipality_id']].append(r)
rows=[]
for m in sorted(set(names)):
 rr=review_by_id[m]; ar=base_by_id[m]
 rows.append({'municipality_id':m,'municipality':names[m],
 'prior_accepted_specific_activity_count':len(ar),
 'new_reviewed_records':len(rr),
 'documented_physical_sites':sum(x['verification_decision']=='CONFIRMADO_SITIO_O_AREA' for x in rr),
 'seasonal_events':sum(x['verification_decision']=='CONFIRMADO_EVENTO_NO_SITIO' for x in rr),
 'regional_experiences':sum(x['verification_decision']=='CONFIRMADO_EXPERIENCIA_NO_SITIO' for x in rr),
 'heritage_not_for_visit':sum(x['verification_decision']=='CONFIRMADO_PATRIMONIO_NO_PROMOCIONAR_VISITA' for x in rr),
 'rejected':sum(x['verification_decision']=='DESCARTADO_COMO_ATRACCION_INDIVIDUAL' for x in rr),
 'accepted_specific_activity_exists':int(bool(ar)),
 'documented_tourism_evidence_exists':int(bool(ar) or any(x['documented_by_credible_source']=='yes' and x['verification_decision']!='DESCARTADO_COMO_ATRACCION_INDIVIDUAL' for x in rr)),
 'comparability_note':'Legacy precise activity features kept separate from new attraction/event evidence; no visitor count inferred'})
write('coverage_212_before_after.csv',rows)
added=[]
for r in review:
 eligible=r['verification_decision']=='CONFIRMADO_SITIO_O_AREA'
 added.append({'evidence_id':r['evidence_id'],'municipality':r['municipality'],'record_name':r['name'],
 'source_url':r['source_url'],'verification_decision':r['verification_decision'],
 'research_catalog_eligible':int(r['verification_decision']!='DESCARTADO_COMO_ATRACCION_INDIVIDUAL'),
 'safe_to_advertise_visitable_now':0,
 'physical_site_to_review_for_content':int(eligible),
 'event_requires_date_verification':int(r['verification_decision']=='CONFIRMADO_EVENTO_NO_SITIO'),
 'visitor_entrance_verified':int(r['confirmed_geographic_point']=='yes' and r['currently_open_or_bookable_confirmed']=='yes'),
 'themes_as_documented':r['themes_original'],
 'limitation':r['visitor_access_note']})
write('verified_14_sources_reviewed.csv',added)
assert sum(r['documented_tourism_evidence_exists'] for r in rows)==75

picks=[r for r in loadcsv(OR) if r['budget_mxn']=='30000']
scens=[r for r in loadcsv(SCENARIO) if r['budget_mxn']=='30000']
assert len(picks)==12
assert set(r['priority'] for r in picks)=={'all','strict'}
assert any(int(r['all_activities_covered'])==47 and int(r['original_text_activities_covered'])==14 for r in scens)
primary={r['municipality_id']:r for r in picks if r['priority']=='all'}
verified={r['municipality_id']:r for r in picks if r['priority']=='strict'}
assert len(primary)==6 and len(verified)==6

# Editorial choices are grounded in the accepted activity pairs, and are not observed audience behavior.
creative={
 '30020':('Artesanías y herencia cultural','Artesanía y cultura viva',
            'En Atlahuilco, descubre la tradición del telar de cintura, los tintes naturales y el trabajo artesanal documentado en el catálogo de experiencias.',
            'Interés hipotético: textiles, talleres artesanales y patrimonio local',
            'Ver experiencias de Atlahuilco','backstrap_loom_weaving'),
 '30032':('Naturaleza y experiencias acuáticas','Naturaleza de Catemaco',
            'Explora Catemaco a través de sus paisajes y experiencias vinculadas con kayak y naturaleza. Consulta los detalles y condiciones antes de planear tu visita.',
            'Interés hipotético: naturaleza, kayak y exploración al aire libre',
            'Descubrir Catemaco','kayaking'),
 '30038':('Café y patrimonio natural','Experiencias de café en Coatepec',
            'Acércate a la cultura del café en Coatepec: degustaciones y experiencias descritas en el catálogo turístico de Veracruz.',
            'Interés hipotético: gastronomía y cultura cafetalera',
            'Explorar el café de Coatepec','coffee_tasting'),
 '30068':('Tradición cafetalera y montaña','Fortín y la cultura del café',
            'Conoce las experiencias relacionadas con el cultivo y la preparación del café registradas para Fortín. Revisa operadores y disponibilidad antes de visitar.',
            'Interés hipotético: cultura cafetalera y escapadas de montaña',
            'Conocer Fortín','coffee_farm_visit'),
 '30124':('Arqueología y tradición','Historia y tradiciones de Papantla',
            'Descubre el patrimonio arqueológico y las experiencias tradicionales vinculadas con Papantla. Comprueba horarios y accesos directamente con cada recinto.',
            'Interés hipotético: historia, patrimonio y tradiciones culturales',
            'Descubrir Papantla','archaeological_visit'),
 '30141':('Cascadas y naturaleza','Naturaleza en San Andrés Tuxtla',
            'Descubre las cascadas y experiencias de naturaleza documentadas para San Andrés Tuxtla. Verifica el acceso y las condiciones antes de tu recorrido.',
            'Interés hipotético: cascadas, naturaleza y aventura',
            'Explorar San Andrés Tuxtla','waterfall_visit'),
}
assert set(creative)==set(primary),'creative does not match optimizer municipality selection'
marketing=[]
for m in sorted(primary):
 focus,title,copy,interest,cta,feature=creative[m]
 pair=next(x for x in base_by_id[m] if x[0]==feature)
 marketing.append({'campaign_id':'PP-30K-'+m,'municipality_id':m,'municipality':names[m],
 'proposed_placement_cost_mxn':5000,'placement_cost_is_measured':'no - classroom assumption',
 'experience_focus':focus,'promotional_headline_es':title,'proposed_copy_es':copy,
 'audience_interest_hypothesis':interest,'proposed_action_es':cta,
 'specific_accepted_activity':feature,'original_passage_count_for_focus':pair[2],
 'source_url':pair[3].split('|')[0],
 'recommended_test':'Discovery creative vs search-intent creative; compare results under equal tracking conditions',
 'primary_kpi':'qualified_destination_guide_views',
 'secondary_kpis':'outbound_source_clicks; route_planner_additions; engaged_sessions',
 'results_status':'proposed_not_executed',
 'availability_status':'not_verified_for_booking'})
write('marketing_portfolio_30000.csv',marketing)

compare=[]
for r in scens:
 compare.append({'scenario':'Maximize diverse accepted activities' if r['priority']=='broad_then_original' else 'Prioritize archived original text',
 'hypothetical_budget_mxn':int(r['budget_mxn']), 'municipalities':int(r['placements']),
 'distinct_accepted_activity_types':int(r['all_activities_covered']),
 'distinct_types_supported_by_original_passages':int(r['original_text_activities_covered']),
 'same_municipalities_between_strategies':int(r['same_selections_in_other_strategy']),
 'measured_visits': 'not estimated', 'campaign_conversion_observations':'not collected'})
write('portfolio_comparison_30000.csv',compare)

# Source-first candidate stories only: no invented promotional performance or observed demand.
pilot=[]
for m,needle,focus in [('30128','Fortaleza de San Carlos','Historia y patrimonio'),('30003','Salto de Ixtagapa','Naturaleza y cascadas')]:
 matches=[r for r in review if r['municipality_id']==m and needle in r['name']]
 if not matches:
  # Perote municipality ID verified from authoritative master and new evidence, not guessed
  matches=[r for r in review if r['municipality']=='Perote' and needle in r['name']]
 if not matches:raise RuntimeError('Could not locate research pilot '+needle)
 r=matches[0]
 pilot.append({'candidate_municipality':r['municipality'],'site':r['name'],'source_url':r['source_url'],
 'audience_test_hypothesis':'Interest in '+focus.lower(),
 'action_before_paid_promotion':'Verify on-site access, current operating status and a suitable landing-page guide',
 'current_status':'research-backed candidate, not an active campaign placement',
 'measured_visitor_demand':'unavailable for this site in joined dataset'})
write('new_evidence_content_pilots.csv',pilot)

kpi=[
 {'metric':'Qualified guide views','definition':'Session viewing a named destination guide with a minimum engagement threshold set before launch','data_required':'Website analytics event','currently_available':'no','use':'Compare content interest by creative/destination'},
 {'metric':'Route planner additions','definition':'Number of distinct attractions added to a plan after visiting a campaign-linked guide','data_required':'Client-side event log; privacy-aware and consent-dependent','currently_available':'no','use':'Proxy for planning intent; not a visit'},
 {'metric':'Outbound provider/source clicks','definition':'Click from destination guide to verified attraction source/operator information','data_required':'Website click events','currently_available':'no','use':'Indication of deeper interest; not a booking'},
 {'metric':'CTR','definition':'Ad clicks divided by ad impressions on a defined platform','data_required':'Real platform campaign results','currently_available':'no','use':'Compare ad-message variants'},
 {'metric':'CPC','definition':'Actual campaign spend divided by paid clicks','data_required':'Ad spend and clicks','currently_available':'no','use':'Cost efficiency after running ads'},
 {'metric':'Incremental tourist visits','definition':'Additional verified visits attributable to campaign with a credible counterfactual','data_required':'Attraction data and research design not currently available','currently_available':'no','use':'Do not claim from the current prototype'},
]
write('measurement_plan.csv',kpi)

summary={'source_sha256':hashlib.sha256(DB.read_bytes()).hexdigest(),'accepted_activity_pairs_old':len(accepted),'old_municipalities_with_accepted_specific_activities':len(base_ids),
 'additional_municipalities_with_external_source_evidence':len(new_ids), 'municipalities_with_documented_activity_or_new_source_evidence':75,
 'all_municipalities':212,'external_evidence_records':40,'new_public_research_records':39,
 'confirmed_physical_sites':26,'confirmed_events':7,'confirmed_regional_experiences':5,
 'archaeology_access_unverified':1,'rejected_generic_record':1,'all_new_attractions_verified_current_access':False,
 'old_pairwise_significance_conclusions_not_transferred_to_enlarged_dataset':True,
 'marketing_budget_assumed_mxn':30000,'assumed_cost_per_placement_mxn':5000,
 'marketing_portfolio_picks':[names[m] for m in primary],
 'origin_of_portfolio':'old frozen exact optimizer - broad-first 6 placements',
 'campaign_results_observed':False}
(OUT/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))

# Map-ready campaign layer; coordinates represent MUNICIPALITY reference points only.
con=sqlite3.connect(f'file:{DB}?mode=ro',uri=True)
loc={r[0]:(r[1],r[2],r[3]) for r in con.execute('select municipality_id,longitude,latitude,coordinate_kind from municipality_georeferences')}
con.close()
geo={'type':'FeatureCollection','metadata':{'purpose':'Proposed promotion portfolio, not booked attraction locations','scenario_budget_mxn':30000,'assumed_cost_per_placement_mxn':5000,'coordinate_scope':'municipality reference points only'},'features':[]}
for r in marketing:
 lng,lat,kind=loc[r['municipality_id']]
 geo['features'].append({'type':'Feature','geometry':{'type':'Point','coordinates':[lng,lat]},'properties':{'municipality_id':r['municipality_id'],'municipality':r['municipality'],'proposed_headline':r['promotional_headline_es'],'promotional_copy':r['proposed_copy_es'],'interest_hypothesis':r['audience_interest_hypothesis'],'source_url':r['source_url'],'coordinate_kind':kind,'routing_ready':False,'campaign_live':False}})
(OUT/'proposed_campaign_municipalities.geojson').write_text(json.dumps(geo,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'proposed_campaign_for_site.json').write_text(json.dumps({'status':'proposed_only','budget_is_hypothetical':True,'items':marketing},ensure_ascii=False,indent=2),encoding='utf-8')
