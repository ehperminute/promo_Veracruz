# Avance 04: Modelos Estocásticos / Markov — Veracruz

Este paquete **no modifica la web, el catálogo turístico ni el SQLite maestro**.

## Qué contiene
- `progress_preguntas/04_Modelos_Estocasticos_Markov_Veracruz_2026-10-18.docx`: informe terminado y editable, pensado para colocarse junto a los documentos anteriores de avance.
- `experiments/stochastic/markov_2026/source_data/datatur_2025_2026_snapshot.csv`: copia versionada de las 53 observaciones DataTur del repositorio de referencia (enero 2025–julio 2026), sin imputar los meses faltantes.
- `experiments/stochastic/markov_2026/run_markov.py`: matrices, predicciones de 2026 y simulación de Markov.
- `experiments/stochastic/markov_2026/sensitivity.py`: análisis con tres pares de umbrales predefinidos.
- `experiments/stochastic/markov_2026/outputs/`: tablas de datos y resultados reproducibles.

## Para reproducir (opcional)
Desde la carpeta de experimento:

    python -m pip install numpy pandas matplotlib
    python run_markov.py
    python sensitivity.py
    python make_charts.py

No hace falta ejecutar nada para leer o entregar el informe. Este avance no certifica que Markov mejore los pronósticos: el resultado de exactitud agregado es 40%, igual que la persistencia.

## Organización
Conservar los reportes antiguos en `progress_preguntas/`; no sobrescribirlos. Si `CURRENT_PROJECT_STATUS.md` o `docs/METHODOLOGY.md` contienen versiones obsoletas, conviene archivarlos en `docs/archive/` antes de borrarlos, para conservar la trazabilidad de las decisiones.

Fuente del conjunto temporal: `data/reference/datatur_veracruz_monthly_2025_2026.csv` de la fotografía del repositorio examinada. Esta no es una revisión nueva de la disponibilidad de los archivos oficiales.
