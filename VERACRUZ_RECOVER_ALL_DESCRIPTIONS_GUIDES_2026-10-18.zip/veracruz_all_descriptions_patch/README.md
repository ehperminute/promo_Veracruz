# Veracruz — Recover original descriptions and integrate into existing tourist guides

The official Veracruz products page currently displays the product descriptions. Our previous master intentionally marked its 295 original product texts as **not recovered**; it saved source-linked paraphrases rather than inventing original wording. This patch uses the **existing** `restore_all_original_products.py` from the October 17 restoration archive, not a newly guessed source parser.

## From your existing `promo_Veracruz` Codespaces checkout

1. Unzip this patch to the repository root (it creates a directory `veracruz_all_descriptions_patch/` and **does not overwrite site files**).
2. Run:

```bash
python -m pip install -r veracruz_all_descriptions_patch/requirements_descriptions.txt
python veracruz_all_descriptions_patch/restore_descriptions_and_guides.py .
```

The program looks for `data/raw/veracruz_productos_2026-10-06.html`; when that historical HTML is available use `--html data/raw/veracruz_productos_2026-10-06.html` explicitly to avoid restoring newer text into the old provenance. Otherwise it fetches the **current** `https://veracruz.mx/productos.php`, clearly tagging the source version.

Requires internet access in your Codespaces environment unless the historical HTML is present. This file was prepared in an environment where downloading HTML directly is blocked; therefore the actual 295-product restore can only be verified after the tool runs in Codespaces. The script refuses a partial restore and leaves map files unchanged on failed source acquisition or title matching.

## What it changes after successful restoration

- `data/recovered_source_descriptions/veracruz_pp3_master_with_originals.sqlite` stores **all 295 original Spanish texts** in a separate copy of the final researched database.
- `data/recovered_source_descriptions/restoration_audit/` contains provenance, recovery exports, original HTML snapshot, and auditing results from the October 17 source restoration script.
- `site/data/map_guide_notes.json` is enriched with short original Spanish source excerpts for **every activity guide directly supported by a matched product**. Other activity guides retain their catalog excerpt or evidence-backed summary; they are not falsely relabeled as the original product description.
- `site/js/map-explorer.js` adds an expandable **Recovered official experience listings** section where relevant. It presents short previews and opens the linked official page for full descriptions. Existing English summaries remain editable and are **not falsely presented as verbatim original text**.
- Marker rendering, coordinates, stylesheets, filters, map style, and existing descriptions in the repository are otherwise unchanged.

The script backs up each site file before modifying it. If the website has a different guide implementation, the script stops instead of replacing the current JS.

## Integrity & scope

295 is the number of website tourism-product cards, *not* the number of geolocated attractions. The map currently has 216 municipality–activity evidence relationships. Some relationships are supported by the original PDF catalog, government sources, or other materials rather than by website product cards. Recovery of 295 originals does **not** magically create new attraction coordinates or current admission/pricing information. For a polished English/Japanese editorial article and photo for each individual activity, an additional review/translation and source/asset verification stage remains necessary.
