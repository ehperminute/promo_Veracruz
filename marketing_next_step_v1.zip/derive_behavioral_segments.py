#!/usr/bin/env python3
"""
Derive behavioral tourist-interest profiles from campaign event logs.

Input:
    campaign_events.csv
    behavioral_segmentation_rules_v1.csv

Expected input columns:
    anonymous_visitor_id, source_market, package_id, themes, event_type, timestamp_utc

`themes` must be a semicolon-separated list such as:
    culture_history;archaeology;heritage;gastronomy

Output:
    visitor_interest_scores.csv

Important:
- This does NOT infer age, income, nationality preferences, or travel history.
- Scores reflect only observed campaign interactions.
- Initial event weights are heuristic and must be recalibrated after real conversions exist.
"""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def load_weights(path: Path) -> dict[str, float]:
    weights: dict[str, float] = {}
    with path.open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            weights[row["event_type"]] = float(row["base_weight"])
    return weights


def split_themes(value: str) -> list[str]:
    return [x.strip() for x in (value or "").split(";") if x.strip()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("events_csv", type=Path)
    parser.add_argument(
        "--rules",
        type=Path,
        default=Path("behavioral_segmentation_rules_v1.csv"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("visitor_interest_scores.csv"),
    )
    args = parser.parse_args()

    weights = load_weights(args.rules)

    # visitor -> theme -> score
    scores: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    markets: dict[str, set[str]] = defaultdict(set)
    packages: dict[str, set[str]] = defaultdict(set)
    event_counts: dict[str, int] = defaultdict(int)
    unknown_events: dict[str, int] = defaultdict(int)

    with args.events_csv.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        required = {
            "anonymous_visitor_id",
            "source_market",
            "package_id",
            "themes",
            "event_type",
            "timestamp_utc",
        }
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        for row in reader:
            visitor = row["anonymous_visitor_id"].strip()
            if not visitor:
                continue

            event_type = row["event_type"].strip()
            weight = weights.get(event_type)
            if weight is None:
                unknown_events[event_type] += 1
                continue

            event_counts[visitor] += 1
            if row["source_market"].strip():
                markets[visitor].add(row["source_market"].strip())
            if row["package_id"].strip():
                packages[visitor].add(row["package_id"].strip())

            for theme in split_themes(row["themes"]):
                scores[visitor][theme] += weight

    all_themes = sorted({theme for per_visitor in scores.values() for theme in per_visitor})

    with args.output.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "anonymous_visitor_id",
            "source_markets",
            "packages_interacted",
            "observed_events_n",
            *[f"score_{theme}" for theme in all_themes],
            "top_interest",
            "top_interest_score",
            "segment_confidence_v1",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        visitors = sorted(set(scores) | set(event_counts))
        for visitor in visitors:
            theme_scores = scores[visitor]
            ranked = sorted(theme_scores.items(), key=lambda x: (-x[1], x[0]))
            top_theme, top_score = ranked[0] if ranked else ("unknown", 0.0)
            second_score = ranked[1][1] if len(ranked) > 1 else 0.0

            # A deliberately simple confidence heuristic.
            # It is NOT a calibrated probability.
            if top_score < 3:
                confidence = "insufficient_signal"
            elif top_score >= 6 and top_score >= second_score * 1.5:
                confidence = "clear_preference"
            else:
                confidence = "mixed_or_early"

            row = {
                "anonymous_visitor_id": visitor,
                "source_markets": "|".join(sorted(markets[visitor])),
                "packages_interacted": "|".join(sorted(packages[visitor])),
                "observed_events_n": event_counts[visitor],
                "top_interest": top_theme,
                "top_interest_score": round(top_score, 3),
                "segment_confidence_v1": confidence,
            }
            for theme in all_themes:
                row[f"score_{theme}"] = round(theme_scores.get(theme, 0.0), 3)

            writer.writerow(row)

    if unknown_events:
        print("Ignored event types not present in the rule table:")
        for event_type, count in sorted(unknown_events.items()):
            print(f"  {event_type}: {count}")

    print(f"Wrote behavioral profiles -> {args.output}")


if __name__ == "__main__":
    main()
