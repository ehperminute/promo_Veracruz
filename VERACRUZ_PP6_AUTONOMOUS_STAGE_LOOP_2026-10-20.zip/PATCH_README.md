# PP6 stage-loop patch — October 20, 2026

## Purpose
An additive execution loop over the **already existing** Veracruz research database and validated experiments. It does **not** redesign the schema, discard the currently researched municipalities, or change the site or map.

## Apply
Extract this ZIP at the root of your `promo_Veracruz` repository, preserving folders. The patch supplies a README, additional scripts, tests, checkpoint and staged experimental artifacts; it updates the old website-export *test* (not the website), requirements (`scipy` added), and `.gitignore` (root ZIP archives ignored). Compare overwrites before applying if your repository changed after the October 20 upload.

Run from repository root:

    python -m pip install -r requirements.txt
    python scripts/pp6/run_loop.py

The runner executes independent S0/S4/S5/S6/S7/S8 checks, 10 scientific tests, scoped repository tests, and a Spanish technical report draft. Each stage writes a checkpoint and logs, retries at most twice, advances independent tasks, and refuses to claim success when a source is unavailable. Read `docs/PP6_BLOCKERS.md` and `outputs/pp6_loop/CHECKPOINT.md`.

## Boundaries
* Complete regeneration from raw requires DENUE/GDP archives excluded from the transfer; no fake substitutes.
* The 55-destination S4 site remains a historical/published version. This patch never refreshes `site/data/`.
* Forecasting and Markov evaluations are **research results**; operational superiority is not established.
* Marketing costs/segments are assumptions and proposals. Real-world venue access and ad outcomes are unverified.
* The technical report is generated and source-linked; individual academic rubric requirements remain to be checked.
* This is a **command-run** loop. It runs while invoked, not in the background after a ChatGPT response.

## Verify archive contents
Includes `PATCH_MANIFEST_SHA256.json` with hashes of each payload file, and `PATCH_README.md`.
