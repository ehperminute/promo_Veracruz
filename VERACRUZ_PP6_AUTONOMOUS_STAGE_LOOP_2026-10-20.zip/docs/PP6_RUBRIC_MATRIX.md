# PP6 rubric-to-evidence tracking (working draft)

This is an evidence-to-deliverable *inventory*, not a claim that unknown current academic rubrics have been satisfied. The student's explicit rubric text is required to certify individual submissions.

| Course | Existing auditable evidence | Claim that is supported | Submission check still pending |
|---|---|---|---|
| Data acquisition / Big Data | SQLite source recovery, 295 restored product descriptions, 212 municipality registry, source snapshot SHA, source registry | Traceable local ETL and validation; not distributed Big Data processing | Required report sections, figures, scalability explanation |
| Data Mining | 216 strict municipality-activity links, 173 with original-text support; activity intersection test; historical Gower/PAM experiments | Evidence-backed offer similarity/discovery, clustering limitations | Required mining algorithm comparisons and association metrics |
| ML | 52 paired center-month predictions, multiple baselines, error uncertainty | Valid retrospective comparison; no convincing improvement over rolling average | Rubric model/metric requirements and correct time scope |
| Stochastic methods | Interval coverage/width per center; negative Markov-vs-persistence finding | Historical calibrated-risk comparison; no statewide probabilistic prediction | Rubric requirement for Markov/simulation formulations |
| OR | Exact six-placement MILP; 47 accepted activity types; robust to original-text criterion | Optimal under declared model and hypothetical cost | Equation presentation, solver evidence, sensitivity/feasibility |
| Digital marketing | 24 controlled campaign-test cells; six-municipality source-backed activity audit | Testable proposal and measurement plan, not actual paid results | Channel-specific deliverables, creative requirements, KPIs, formatting |
| Final integrated report | Existing ES/EN drafts; stage checkpoint and limitations | Source-linked integrated narrative if reconciled to current data | Rubric-based review, final citations, course-specific versions |

Research is not to be rerun merely because a report is incomplete. Report gaps are writing/rubric work; empirical gaps are research work.
